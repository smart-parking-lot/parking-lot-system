import time
import numpy as np
import tensorflow as tf
from tensorflow import keras  ##PC、docker、colab用keras
from tensorflow.keras.models import load_model
import cv2
import os  # !pip install os_sys


def load_labels(path):
    with open(path, 'r') as f:
        return {i: line.strip() for i, line in enumerate(f.readlines())}


def main(label_path, model_path, img_name, img_parent_path):
    labels = load_labels(label_path)
    model = load_model(model_path, compile=False)
    print("Model Loaded Successfully.")
    #print(model.layers[0])
    #_, height, width, channel = model.layers[0].output_shape[0]  #why teachable machine didn't have this
    (height, width, channel) = (224, 224, 3)
    #print("Required input Shape ({}, {}, {})".format(height, width, channel))

    # load image for inference
    img_path = img_parent_path + "/" + img_name
    #print(img_path) 
    image = cv2.imread(img_path)
    #print(image.shape)  #AttributeError: 'NoneType' object has no attribute 'shape'   發生原因:因為路徑包含中文，所以無法識別，所以讀取不到圖片檔
    image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
    image = cv2.resize(image, (width, height))
    #print(image.shape)
    image = image / 255.0
    image = np.reshape(image, (1, height, width, channel))
    #print(image.shape)

    # run inference on input image
    results = model.predict(image)[0]  # inference first time
    #start_time = time.time()
    results = model.predict(image)[0]  # inference second time
    #stop_time = time.time()
    label_id = np.argmax(results)
    prob = results[label_id]

    # print predict result~
    #print(50 * "=")
    print("Object in {} is a/an...".format(img_name))
    print("{}! \nConfidence={}".format(labels[label_id], prob))
    #print(50 * "=")
    #print("Time spend: {:.5f} sec.".format(stop_time - start_time))

def read_all_imgs(img_parent_path):
    files_and_directory_names = os.listdir(img_parent_path)
    photo_name = [ele   for ele in files_and_directory_names   if ".jpg" in ele or ".png" in ele] 
    #print(photo_name )
    return photo_name

if __name__ == "__main__":
    print(tf.__version__)
    label_path = './PC/labels.txt'
    model_path = './PC/keras_model.h5'  ##助教訓練好的模型  #路徑不能包含中文，會無法識別，讀取不到
    img_parent_path = './test'
    for ele in read_all_imgs(img_parent_path):
        print(50 * "=")
        img_name = ele  # <- you can change to any other test sample in "cifar10_subset" folder
        main(label_path, model_path, img_name, img_parent_path)
        #print('one img done')
        print(50 * "=")